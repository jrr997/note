var Px2rem = require('./px2rem.js');
var px2remIns = new Px2rem();
var originCssText = 'body { font-size: 12px; }';
var dpr = 2;
var newCssText = px2remIns.generateRem(originCssText); // generate rem version stylesheet
// var newCssText = px2remIns.generateThree(originCssText, dpr); // generate @1x, @2x and @3x version stylesheet

console.log(newCssText);